﻿/**
 * @unit    SWU-SEN-002
 * @name    Temperature Sensor Driver
 * @type    function
 * @asil    A
 * @sdd     SDD-SEN-002
 * @req     SWR-SEN-003
 * @author  A. Guerrero
 * @date    2026-05-04
 * @status  approved
 *
 * Reads NTC thermistor via ADC and converts to Celsius.
 */

#include "temperature_sensor.h"
#include <stdint.h>
#include <math.h>

#define NTC_BETA        3950.0f   /* NTC beta coefficient */
#define NTC_R25         10000.0f  /* Resistance at 25Â°C (Ohms) */
#define NTC_R_SERIES    10000.0f  /* Series resistor (Ohms) */
#define T0_KELVIN       298.15f   /* 25Â°C in Kelvin */
#define ADC_RESOLUTION  4096      /* 12-bit ADC */
#define ADC_VREF        3.3f      /* Reference voltage */

/**
 * @unit    SWU-SEN-002
 * @name    Temperature Sensor Driver
 * @type    function
 * @asil    A
 * @sdd     SDD-SEN-002
 * @req     SWR-SEN-003
 * @author  A. Guerrero
 * @date    2026-05-04
 * @status  approved
 *
 * Reads NTC thermistor via ADC and converts to Celsius.
 */
float temperature_read_celsius(void) {
    uint16_t adc_raw = adc_read_channel(ADC_CHANNEL_TEMP);

    /* Voltage divider: V_ntc = Vref * adc / resolution */
    float v_ntc = ADC_VREF * ((float)adc_raw / ADC_RESOLUTION);

    /* NTC resistance from voltage divider */
    float r_ntc = NTC_R_SERIES * v_ntc / (ADC_VREF - v_ntc);

    /* Steinhart-Hart (simplified Beta equation) */
    float temp_k = 1.0f / (1.0f / T0_KELVIN + logf(r_ntc / NTC_R25) / NTC_BETA);

    return temp_k - 273.15f;  /* Kelvin to Celsius */
}

/**
 * @unit    SWU-SEN-002
 * @name    Temperature Sensor Driver
 * @type    function
 * @asil    A
 * @sdd     SDD-SEN-002
 * @req     SWR-SEN-003
 * @author  A. Guerrero
 * @date    2026-05-04
 * @status  approved
 *
 * Reads NTC thermistor via ADC and converts to Celsius.
 */
bool temperature_is_critical(float limit_celsius) {
    return temperature_read_celsius() >= limit_celsius;
}
